// Matrix Multiplication using Multithreading
// read data from Metrices.txt file, use of DMA at threads, file system, multiply algorithms and resuslt
// Compile this code: gcc task1.c -o task1 -pthread
// For result: ./task1
// Please check matrixresults2050215.txt for matrix multiplication results.
// Note this program was executed in window. 

#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>

FILE *fp;
int i, j, k, l, m, n, count=0;
pthread_mutex_t mtx;
char *result = "MatrixResults2050114.txt";


void merge(){
    FILE *f1, *f2, *f3, *f4, *f5 = NULL;
    int rw, cl, rws, cls;      // variable for rw=row, rows=rws, column=cl, columns=cls
    float mtv = 0.0;        // define variable for matrix value (mtv)
    f1 = fopen("SampleMatricesWithErrors.txt", "r");
    f2 = fopen("SampleMatricesWithErrors2.txt", "r");
    f3 = fopen("SampleMatricesWithErrors3.txt", "r");
    f4 = fopen("SampleMatricesWithErrors4.txt", "r");
    f5 = fopen("SampleMatricesWithErrors5.txt", "r");
    fp = fopen("Matrices.txt", "w");

    // First Matrices files values are read and write in Matrices file
    while(!feof(f1)){
        fscanf(f1,"%d,%d",&rws, &cls);
        fprintf(fp, "%d,%d\n", rws, cls);
        for(rw = 0; rw < rws; rw++){        // loop for rws
            for(cl = 0; cl < cls-1; cl++){    // loop for clumns
                fscanf(f1,"%f,",&mtv);           // scan value from file 
                fprintf(fp, "%f,", mtv);
            }
            fscanf(f1,"%f\n",&mtv);
            fprintf(fp, "%f\n", mtv);
        }
    }
    fclose(f1);
    
    // Second Matrices files values are read and write in Matrices file
    while(!feof(f2)){
        fscanf(f2,"%d,%d",&rws, &cls);
        fprintf(fp, "%d,%d\n", rws, cls);
        for(rw = 0; rw < rws; rw++){        // loop for rws
            for(cl = 0; cl < cls-1; cl++){    // loop for clumns
                fscanf(f2,"%f,",&mtv);           // scan value from file 
                fprintf(fp, "%f,", mtv);
            }
            fscanf(f2,"%f\n",&mtv);
            fprintf(fp, "%f\n", mtv);
        }
    }
    fclose(f2);

    // Third Matrices files values are read and write in Matrices file
    while(!feof(f3)){
        fscanf(f3,"%d,%d",&rws, &cls);
        fprintf(fp, "%d,%d\n", rws, cls);
        for(rw = 0; rw < rws; rw++){        // loop for rws
            for(cl = 0; cl < cls-1; cl++){    // loop for clumns
                fscanf(f3,"%f,",&mtv);           // scan value from file 
                fprintf(fp, "%f,", mtv);
            }
            fscanf(f3,"%f\n",&mtv);
            fprintf(fp, "%f\n", mtv);
        }
    }
    fclose(f3);

    // Fourth Matrices files values are read and write in Matrices file
    while(!feof(f4)){
        fscanf(f4,"%d,%d",&rws, &cls);
        fprintf(fp, "%d,%d\n", rws, cls);
        count++;
        for(rw = 0; rw < rws; rw++){        // loop for rws
            for(cl = 0; cl < cls-1; cl++){    // loop for clumns
                fscanf(f4,"%f,",&mtv);           // scan value from file 
                fprintf(fp, "%f,", mtv);        // store in fp file
            }
            fscanf(f4,"%f\n",&mtv);
            fprintf(fp, "%f\n", mtv);
        }
    }
    fclose(f4);

    // Fifth Matrices files values are read and write in Matrices file
    while(!feof(f5)){
        fscanf(f5,"%d,%d",&rws, &cls);
        fprintf(fp, "%d,%d\n", rws, cls);
        for(rw = 0; rw < rws; rw++){        // loop for rws
            for(cl = 0; cl < cls-1; cl++){    // loop for clumns
                fscanf(f5,"%f,",&mtv);           // scan value from file 
                fprintf(fp, "%f,", mtv);
            }
            fscanf(f5,"%f\n",&mtv);
            fprintf(fp, "%f\n", mtv);
        }
    }
    fclose(f5);
    fclose(fp);
}

// structure for matrix for multithreading
struct matrix_value_var{
    int matrix_row, matrix_column;
    double matrix_value;
};
// Strucuture for two matrices value
struct matrix_couplet{
    struct matrix_value_var *matrix_value_var;
};
// Structure for multithreading values
struct threadStructure{
    int start,finish, sliceSize,th_id;
    struct matrix_couplet *matrix_couplet;
};
double *matrix_array(int matSize)
{
  double *matArr = (double *)malloc(sizeof(double) * matSize);
  return matArr;
}
int getMatrixValueIndex(int r, int c, int nc)
{
  return r * nc + c;
}

void matrix_output(struct matrix_value_var matrix){
    pthread_mutex_lock(&mtx);
    fp = fopen(result, "w");
    fprintf(fp, "%d,%d\n", matrix.matrix_row, matrix.matrix_column);
    for (int i = 0; i < matrix.matrix_row; i++){
        for (int j = 0; j < matrix.matrix_column; j++){
            fprintf(fp, "%lf ", matrix.matrix_value[getMatrixValueIndex(i, j, matrix.matrix_column)]);
        }
        fprintf(fp, "\n");
    }
    fprintf(fp, "\n");
    fclose(fp);
    pthread_mutex_unlock(&mtx);
}

void mat_multiplicaion_process(struct matrix_couplet *matrix_couplet){
    struct matrix_value_var P = matrix_couplet->matrix_value_var[0];
    struct matrix_value_var Q = matrix_couplet->matrix_value_var[1];
    if (P.matrix_column != Q.matrix_row){
        printf("Error!");
    }else{
        struct matrix_value_var R;
        R.matrix_row = P.matrix_row;
        R.matrix_column = Q.matrix_column;
        R.matrix_value = matrix_array(R.matrix_row * R.matrix_column);
        for (i = 0; i < R.matrix_row; i++){
            for (j = 0; j < R.matrix_column; j++){
                R.matrix_value[getMatrixValueIndex(i, j, R.matrix_column)] = 0.0;
                for (k = 0; k < Q.matrix_row; k++){
                    R.matrix_value[getMatrixValueIndex(i, j, k, R.matrix_column)] += P.matrix_value[getMatrixValueIndex(i, j, k, P.matrix_column)] * Q.matrix_value[getMatrixValueIndex(i, j, k, Q.matrix_column)];
                }
            }
        }
        matrix_output(R);
    }

}

void *multiplications_inThread(void *arg){
    struct threadStructure *thread_data = (struct threadStructure *)arg;
    int tid = thread_data->th_id;
    int sliceSize = thread_data->sliceSize;
    int start = thread_data->start;
    int finish = thread_data->finish;
    struct matrix_couplet *matrix_couplet = thread_data->matrix_couplet;
    
    if (sliceSize > 0){
        for (i = start; i <= finish; i++){
            mat_multiplicaion_process(&matrix_couplet[i]);
        }
        return NULL;
    }
    return NULL;
}

void matrix_sum(struct matrix_couplet *matrix_couplet_lst, char *m_data[], int n){
    int mat_ix = 0;
    for ( i = 0; i < n; i++){
        fp = fopen(m_data[i], "r");
        while (!feof(fp)){
            struct matrix_couplet *mat_c = (struct matrix_couplet *)malloc(sizeof(struct matrix_couplet));
            mat_c->matrix_value_var = (struct matrix_value_var *)malloc(sizeof(struct matrix_value_var) * 2);
            for (int i = 0; i < 2; i++){
                struct matrix_value_var *matrix;
                matrix = &matrix_couplet->matrix[i];
                fscanf(fp, "%d,%d", &matrix->matrix_row, &matrix->matrix_column);
                matrix->matrix_value = matrix_array(matrix->matrix_row* matrix->matrix_column);

                int n = 0;
                double t_value = 0.0;
                for (i = 0; i < matrix->matrix_row; i++){
                    for (j = 0; j < matrix->matrix_column - 1; j++){
                        fscanf(fp, "%lf,", &t_value);
                        matrix->matrix_value[getMatrixValueIndex(i, j, matrix->matrix_column)] = t_value;
                    }
                    fscanf(fp, "%lf\n", &t_value);
                    matrix->matrix_value[getMatrixValueIndex(i, matrix->matrix_column - 1, matrix->matrix_column)] = t_value;
                }
        }
        matrix_couplet_lst[mat_ix] = *mat_c;
        mat_ix++;

        free(mat_c);
        }
        
    }
    
}

int main() {
    int number_of_threads;
    int file_no = 1;
    merge();
    int rw, cl, rws, cls;
    float mtv = 0.0;
    fp = fopen("Matrices.txt", "r");
    while(!feof(fp)){
        fscanf(fp,"%d,%d",&rws, &cls);
        printf("Rows: %d, Columns: %d\n", rws, cls);
        count ++;
        for(rw = 0; rw < rws; rw++){        // loop for rws
            for(cl = 0; cl < cls-1; cl++){    // loop for clumns
                fscanf(fp,"%f,",&mtv);           // scan value from file 
                printf("%f\t",mtv); 
                
            }
            fscanf(fp,"%f\n",&mtv);
            printf("%f\n",mtv);
        }
    }
    printf("\nTotal Number of Matrices: %d\n", count);
    fclose(fp);

    printf("\nEnter number of threads: ");
	scanf("%d", &number_of_threads);

    char * file[] = {"Matrices.txt"};
    struct matrix_couplet *matrix_couplet_list = (struct matrix_couplet *)malloc(sizeof(struct matrix_couplet) * count);
    matrix_sum(matrix_couplet_list, file, file_no);

    int *sliceThread = (int *)malloc(sizeof(int) * number_of_threads);
    int rem = count % number_of_threads;
    // Divide the threads
    for (i = 0; i < number_of_threads; i++){
        sliceThread[i] = count / number_of_threads;
    }
    // Remainder for threads
    for (i = 0; i < rem; i++){
        sliceThread[i] = sliceThread[i] + 1;
    }
    // Dynamically divide matrix values in eaul part with help of DMA
    int *start = (int *)malloc(sizeof(int) * number_of_threads);
    int *finish = (int *)malloc(sizeof(int) * number_of_threads);
    for (int i = 0; i < number_of_threads; i++){
        if (i == 0){
            start[i] = 0;
        }else{
            start[i] = finish[i - 1] + 1;
        }
        finish[i] = start[i] + sliceThread[i] - 1;
    }
    // DMA for inThread multiplication of matrix
    struct threadStructure *thData = (struct threadStructure *)malloc(sizeof(struct threadStructure) * number_of_threads);
    for (int i = 0; i < number_of_threads; i++){
        thData[i].th_id = i;
        thData[i].sliceSize= sliceThread[i];
        thData[i].start = start[i];
        thData[i].finish = finish[i];
        thData[i].matrix_couplet = matrix_couplet_list;
    }

    pthread_t thread[number_of_threads]; //create thread
    pthread_mutex_init(&mtx, NULL); // lock mutex
    for (int i = 0; i < number_of_threads; i++){
        pthread_attr_t attr;
        pthread_attr_init(&attr);
        pthread_create(&thread[i], &attr, multiplications_inThread, (void *)&thData[i]);
    }
    // thread join
    for (int i = 0; i < number_of_threads; i++){
       pthread_join(thread[i], NULL);
    }
    // Destory mutex
    pthread_mutex_destroy(&mtx);
    // heap memory free
    for (int i = 0; i < count; i++){
        for (int j = 0; j < 2; j++){
            free(matrix_couplet_list[i].matrix_value_var[j].matrix_value);
        }
        free(matrix_couplet_list[i].matrix_value_var);
    }
    free(matrix_couplet_list);
    free(start);
    free(sliceThread);
	free(finish);
	free(thData);

    printf("Metrices are multiplied Successfully!\n");
    printf("Please check matrixresults2050215.txt file for multiplication of matrices.\n");

    return 0;
}

