//Password cracking using Multithreading
//  Compile with:
	// cc -o tas2 tas2.c -lcrypt -pthread 

// Run with:
    // ./tas2

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <crypt.h>
#include <unistd.h>
#include <pthread.h>
#include <time.h>
#include <math.h>

//ecryption 
char *enc = "$6$AS$xtU7UEO72OWJkZY.gs.rAzQzjx1Rbizk6dXovpoqhn0oWombXcxNA6Gyvi8VRRCPpT.yIZH5ocxVXYTyhOtaI0";
pthread_cryp_tex_t cryp_tex;
//variable declaration
int threadNum;
int c=0;
int i;
FILE * f;
//defining struct 
struct hash_code
{
    int starting_point;
    int ending_point;
};

void substr(char *d, char *s, int starting_point, int l)
{
    memcpy(d, s + starting_point, l);
    *(d + l) = '\0';
}


//function
void *func2(void *catch)
{
    int x, y, z, a; 
    char salt[7];   
    char plain[7];  
    char *e;             
    
    

    substr(salt,enc, 0, 6);
        //to read txt cracked file
    	f = fopen("CrackedPass.txt","w");

    struct hash_code *ptr = (struct hash_code *)catch;
    int start = ptr->starting_point;
    int end = ptr->ending_point;
    printf("sjdvhsj");

    //nested loop for possible input passwords
    for (i = start; i <= end; i++)
    {
        pthread_cryp_tex_lock(&cryp_tex);

        for (x = 'A'; x <= 'Z'; x++)
        {
            for (y = 'A'; y <= 'Z'; y++)
            {
                for (z = 0; z <= 9; z++)
                {
                    for (a = 0; a <= 9; a++)
                    {
                        sprintf(plain, "%c%c%d%d", x, y, z, a);
                        e = (char *)crypt(plain, salt);
                        c++;
                        if (strcmp(enc, e) == 0)
                        {
                            fprintf(f,"#%-8d%s %s\n", c, plain, e);
                            exit(0);
                        }
                        else
                        {
                            fprintf(f,"%-8d%s %s\n", c, plain, e);

                        }
                    }
                }
            }
        }
        pthread_cryp_tex_unlock(&cryp_tex);

        fclose(f);
    }
}

int main(int argc, char *argv[])
{
    int x, y, z, a;
    //user input for thread
    printf("Enter number  of thread: ");
    scanf("%d", &threadNum);

    for (x = 'A'; x <= 'Z'; x++)
    {
        for (y = 'A'; y <= 'Z'; y++)
        {
            for (z = 0; z <= 9; z++)
            {
                for (a = 0; a <= 9; a++)
                {
                    c++;
                }
            }
        }
    }
    //thread slicing
    pthread_t id[threadNum];
    struct hash_code s[threadNum];
    int slice_list[threadNum];
    //dividing thread
    for (i = 0; i < threadNum; i++)
    {
        slice_list[i] = c / threadNum;
    }
    int rem = c % threadNum;
    //remainder of threads
    for (i = 0; i < rem; i++)
    {
        slice_list[i] = slice_list[i] + 1;
    }

    for (i = 0; i < threadNum; i++)
    {
        if (i == 0)
        {
            s[i].starting_point = 1;
        }
        else
        {
            s[i].starting_point = s[i - 1].ending_point + 1;
        }
        s[i].ending_point = s[i].starting_point + slice_list[i] - 1;
    }


    pthread_cryp_tex_init(&cryp_tex, NULL);
    pthread_t thread_2[threadNum];
    //create thread
    for (i = 0; i < threadNum; i++)
    {
        pthread_create(&thread_2[i], NULL, (void *)func2, &s[i]);
    }
    //thread join
    for (i = 0; i < threadNum; i++)
    {
        pthread_join(thread_2[i], NULL);
    }
    //cryp destroy
    pthread_cryp_tex_destroy(&cryp_tex);

  

    return 0;
}
